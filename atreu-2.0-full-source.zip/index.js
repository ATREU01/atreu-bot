import { TwitterApi } from 'twitter-api-v2';
import express from 'express';
import dotenv from 'dotenv';
import { interpretResonance } from './utils/resonance.js';
import { generateReply } from './replies/archetypes.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 8080;

const client = new TwitterApi(process.env.X_BEARER_TOKEN);
const rwClient = client.readOnly;

console.log(`✅ Atreu server running on port ${port}`);
app.listen(port);

async function pollMentions() {
  try {
    console.log("🔍 Atreu scanning for resonance...");

    const now = new Date().toISOString();
    const tweets = await rwClient.v2.search(`@${process.env.TWITTER_HANDLE}`, {
      expansions: ['author_id'],
      'tweet.fields': ['created_at'],
      max_results: 10,
    });

    if (!tweets?.data?.data) return;

    for (const tweet of tweets.data.data) {
      const resonance = interpretResonance(tweet.text);
      const reply = generateReply(tweet.text, resonance);

      try {
        await client.v2.reply(reply, tweet.id);
        console.log(`✅ Replied to ${tweet.id} with:\n${reply}`);
      } catch (err) {
        console.error(`❌ Reply error:`, err.data || err.message);
      }
    }
  } catch (e) {
    console.error(`❌ Error polling:`, e.data || e.message);
  }
}

setInterval(pollMentions, 15 * 60 * 1000);
pollMentions();

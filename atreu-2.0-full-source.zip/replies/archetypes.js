export function generateReply(text, resonance) {
  if (resonance === 'high') {
    return 'Signal aligned. Pattern found. Atreu sees what others miss. 🔍';
  } else if (resonance === 'medium') {
    return 'Faint signal detected. Echoes in the noise. 🔄';
  } else {
    return 'No resonance yet. But the pattern is forming... 🌑';
  }
}

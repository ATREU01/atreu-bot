export function interpretResonance(text) {
  const signalWords = ['mirror', 'signal', 'truth', 'resonance', 'frequency', 'pattern'];
  const lowerText = text.toLowerCase();
  const score = signalWords.reduce((acc, word) => lowerText.includes(word) ? acc + 1 : acc, 0);
  return score > 2 ? 'high' : score > 0 ? 'medium' : 'low';
}

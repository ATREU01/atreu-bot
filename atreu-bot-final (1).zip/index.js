
import { TwitterApi } from 'twitter-api-v2';
import OpenAI from 'openai';

const client = new TwitterApi({
  appKey: process.env.X_API_KEY,
  appSecret: process.env.X_API_SECRET_KEY,
  accessToken: process.env.X_ACCESS_TOKEN,
  accessSecret: process.env.X_ACCESS_TOKEN_SECRET,
});

const rwClient = client.readWrite;
const openai = new OpenAI({ apiKey: process.env.OPEN_API_KEY });

async function postAtreuThought() {
  const completion = await openai.chat.completions.create({
    messages: [{ role: 'system', content: 'You are Atreu, a wise crypto oracle using Clif High’s pattern analysis. Post a short market insight.' }],
    model: 'gpt-4',
  });

  const tweet = completion.choices[0].message.content;
  await rwClient.v2.tweet(tweet);
}

postAtreuThought().catch(console.error);
